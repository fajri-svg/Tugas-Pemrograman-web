<?php
class product extends CI_Controller {

        public function index()
        {
                $this->load->view('product');
        }

        public function page()
        {
                $data['page_title'] = 'Muhammad Fajri Aushaf';
                $data['body'] = 'isi';
                $this->load->view('top',$data);
                $this->load->view('header');
                $this->load->view('content');
                $this->load->view('footer');
        }
}