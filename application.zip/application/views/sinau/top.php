<h1><?php echo $page_title;?></h1>
<p><?php echo $body;?></p>
