<marquee><h1>ini header</h1></marquee>

<style>
    h1{
        color: blue
    }
</style>