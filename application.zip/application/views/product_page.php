<html>
<head>
    <title>Product Page</title>
</head>
<body>
  <div id="scroll-text">
      <h1>Ini adalah halaman Product</h1></div>
    
    <style>
        #scroll-text {
        text-align: right;
        -moz-transform: translateX(-100%);
        -webkit-transform: translateX(-100%);
        transform: translateX(-100%);
        
        -moz-animation: my-animation 15s linear infinite;
        -webkit-animation: my-animation 15s linear infinite;
        animation: my-animation 15s linear infinite;
        }

        @-webkit-keyframes my-animation {
        from { -webkit-transform: translateX(-100%); }
        to { -webkit-transform: translateX(100%); }
        }

        @keyframes my-animation {
        from {
            -moz-transform: translateX(-100%);
            -webkit-transform: translateX(-100%);
            transform: translateX(-100%);
        }
        to {
            -moz-transform: translateX(100%);
            -webkit-transform: translateX(100%);
            transform: translateX(100%);
        }
}
    </style>
</body>
</html>