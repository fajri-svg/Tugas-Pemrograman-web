<html>
<head>
    <title>Product Page</title>
</head>
<body>
  <div id="scroll-text">
      <marquee><h1>Ini adalah halaman Product</h1></marquee>
    </style>
</body>
</html>